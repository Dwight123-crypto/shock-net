<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WaterRefilling extends Model
{
	public $fillable = ['entry_no', 'customer_id', 'return_bottle', 'order_qty', 'amount_due', 'date','refill_bottle','others_qty'];
}