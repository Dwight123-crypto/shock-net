<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WRMExpenses extends Model
{
    public $fillable = ['id','vendor_id', 'invoice_no', 'terms', 'period', 'amount', 'description','date'];
}
