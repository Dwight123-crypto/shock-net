<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WaterRefilling extends Model
{
	public $fillable = [
	'id',
	'pro_id',
	'entry_no', 
	'customer_id', 
	'return_bottle', 
	'order_qty', 
	'amount_due', 
	'date',
	'refill_bottle',
	'others_qty',
	'dealer_qty',
	'container_qty',
	'status',
	'amt_balance'
	];
}