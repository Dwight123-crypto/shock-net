<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use App\Payroll;
use App\Option;
use App\Voucher;
use App\ChartAccount;
use App\Cashadvance;
use DB;
use Carbon\Carbon;
use DateTime;
use Artisan;

class PayrollController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request){

        // Artisan::call('config:clear');
        // Artisan::call('config:cache');

        $employees = Employee::orderBy('employee_name', 'ASC')
        ->orderBy('employee_name', 'ASC')
        ->get();
        return view('payroll.index', compact('employees'));
    }

    public function createDailyPayroll(Request $request){

        // $coas = [];
        // $coas['debit']   = $this->getCoaDebits();
        // $coas['credit']  = $this->getCoaCredits();

        $emp_id = $request->employee_id;
        if(!is_numeric($emp_id)){
            return back()->with('warning', 'Please select an Employee to create Payroll!');
        }

        $chart_accounts = ChartAccount::orderby('name')->get();
        
        $ca_amount = Cashadvance::where('e_id', $emp_id)->sum('ca_amount');
        $ca_deduction = Cashadvance::where('e_id', $emp_id)->sum('ca_deduction');
        $total_ca_amount = $ca_amount - $ca_deduction;

        $employees_data = DB::table('employees')
        ->where('id', $emp_id)
        ->first();
        return view('payroll.create-daily-payroll', compact('employees_data','chart_accounts', 'total_ca_amount'));
    }

    public function createMonthlyPayroll(Request $request){

        $emp_id = $request->employee_id;
        if(!is_numeric($emp_id)){
            return back()->with('warning', 'Please select an Employee to create Payroll!');
        }

        $chart_accounts = ChartAccount::orderby('name')->get();

        $ca_amount = Cashadvance::where('e_id', $emp_id)->sum('ca_amount');
        $ca_deduction = Cashadvance::where('e_id', $emp_id)->sum('ca_deduction');
        $total_ca_amount = $ca_amount - $ca_deduction;

        $employees_data = DB::table('employees')
        ->where('id', $emp_id)
        ->first();
        return view('payroll.create-monthly-payroll', compact('employees_data','chart_accounts', 'total_ca_amount'));
    }

    public function savePayroll(Request $request){

        // $p = new Payroll();
        // dd($p->getFillable());

        $pr = Payroll::create($request->all());
        
        $pr_last_rec = DB::table('payrolls')->latest()->first();
        $pay_id = 'pr-'.$pr_last_rec->pay_id;
        
        $pr_date = date('Y-m-d', strtotime($pr->created_at));
        $pr_alias = 'pr';
        $order = 0;

        $ca_deducted = $request->ca_deducted;
        if(!empty($ca_deducted)){
            $ca_key = 'cd-'.$pr_last_rec->pay_id;
            $cashAdvance = new Cashadvance();
            $cashAdvance->ca_deduction = $ca_deducted;
            $cashAdvance->keys = $ca_key;
            $cashAdvance->e_id = $request->e_id;
            $cashAdvance->date = $pr_date;
            $cashAdvance->save();
        }

        foreach($request->vouchers as $voucher){

            $float_debit  = str_replace( ',', '', $voucher['debit']);
            $float_credit  = str_replace( ',', '', $voucher['credit']);

            $voucher['ref_id']       = $voucher['chart_account_id'];
            $voucher['ref_number']   = $pay_id;
            $voucher['module_alias'] = $pr_alias;
            $voucher['order']        = $order;
            $voucher['debit']        = $float_debit;
            $voucher['credit']       = $float_credit;
            $voucher['date']         = $pr_date;

            Voucher::create($voucher);
            $order++;
        }

        return redirect()->route('payroll.index')
        ->with('success','Employee payroll is successfully created.');
    }

    public function editDailyPayroll($id){

        $edit_payroll = Payroll::where('pay_id', $id)
        ->first();
        
        $chart_accounts = ChartAccount::orderby('name')->get();

        $key = 'cd-'.$id;
        $ca_deducted = Cashadvance::where('keys', $key)->first();

        $pr_id = 'pr-'.$id;
        $vouchers_rec = Voucher::where('ref_number', $pr_id)
        ->orderby('order')
        ->get();

        $employee_id = $edit_payroll->e_id;
        $employee_info = Employee::where('id', $employee_id)
        ->first();
        return view('payroll.edit-daily-payroll', compact(
            'edit_payroll',
            'employee_info',
            'chart_accounts',
            'vouchers_rec',
            'ca_deducted'
        ));
    }

    public function editMonthlyPayroll($id){
        $edit_payroll = Payroll::where('pay_id', $id)
        ->first();
    
        $chart_accounts = ChartAccount::orderby('name')->get();

        $key = 'cd-'.$id;
        $ca_deducted = Cashadvance::where('keys', $key)->first();

        $pr_id = 'pr-'.$id;
        $vouchers_rec = Voucher::where('ref_number', $pr_id)
        ->orderby('order')
        ->get();

        $employee_id = $edit_payroll->e_id;
        $employee_info = Employee::where('id', $employee_id)
        ->first();
        return view('payroll.edit-monthly-payroll', compact(
            'edit_payroll',
            'employee_info',
            'chart_accounts',
            'vouchers_rec',
            'ca_deducted'
        ));
    }

    public function updatePayroll(Request $request)
    {
        // dd($request->vouchers);
        // $ca_deducted = str_replace( ',', '', $request->ca_deducted);
        // dd($ca_deducted);
        $pay_id = $request->pay_id;
        $pr_alias = 'pr-'.$pay_id;
        
        $order = 0;

        foreach($request->vouchers as $voucher){

            $v_id = $voucher['id'];

            $float_debit  = str_replace( ',', '', $voucher['debit']);
            $float_credit  = str_replace( ',', '', $voucher['credit']);
            // dd($float_credit);

            $voucher['ref_number']   = $pr_alias;
            $voucher['ref_id']       = $voucher['chart_account_id'];
            $voucher['order']        = $order;
            $voucher['debit']        = $float_debit;
            $voucher['credit']       = $float_credit;

            Voucher::where('id', $v_id)->update($voucher);
            $order++;
        }

        $ca_deducted = str_replace( ',', '', $request->ca_deducted);
        $key = 'cd-'.$pay_id;
        if(!empty($ca_deducted)){
            Cashadvance::where('keys', $key)->update([
                'ca_deduction' => $ca_deducted,
                'date' => $request->date,
                'keys' =>  $key
            ]);
        }

        if (!empty($request->e_id) && $request->salary_method == "D") {

            Payroll::where('pay_id', $pay_id)->update([
                'e_id' => $request->e_id,
                'salary_days_present' =>  $request->salary_days_present,
                'salary_rate' => $request->salary_rate,
                'salary_total' => $request->salary_total,
                'overtime' => $request->overtime,
                'overtime_rate' => $request->overtime_rate,
                'overtime_total' => $request->overtime_total,
                'cola' => $request->cola,
                'total' => $request->total,
                'emp_con_sss' => $request->emp_con_sss,
                'emp_con_phic' => $request->emp_con_phic,
                'emp_con_pagibig' => $request->emp_con_pagibig,
                'late' => $request->late,
                'late_rate' => $request->late_rate,
                'late_total' => $request->late_total,
                'employer_con_sss' => $request->employer_con_sss,
                'employer_con_phic' => $request->employer_con_phic,
                'employer_con_pagibig' => $request->employer_con_pagibig,
                'holiday' => $request->holiday,
                'net_pay' => $request->net_pay,
                'tax_withheld' => $request->tax_withheld,
                'salary_method' => $request->salary_method,
                'date' => $request->date,
            ]);

        }elseif (!empty($request->e_id) && $request->salary_method == "M"){

            Payroll::where('pay_id', $pay_id)->update([
                'e_id' => $request->e_id,
                'salary_rate' => $request->salary_rate,
                'salary_total' => $request->salary_total,
                'overtime' => $request->overtime,
                'overtime_rate' => $request->overtime_rate,
                'overtime_total' => $request->overtime_total,
                'cola' => $request->cola,
                'total' => $request->total,
                'emp_con_sss' => $request->emp_con_sss,
                'emp_con_phic' => $request->emp_con_phic,
                'emp_con_pagibig' => $request->emp_con_pagibig,
                'late' => $request->late,
                'late_rate' => $request->late_rate,
                'late_total' => $request->late_total,
                'employer_con_sss' => $request->employer_con_sss,
                'employer_con_phic' => $request->employer_con_phic,
                'employer_con_pagibig' => $request->employer_con_pagibig,
                'days_absent' => $request->days_absent,
                'absent_rate' => $request->absent_rate,
                'absent_total' => $request->absent_total,
                'holiday' => $request->holiday,
                'net_pay' => $request->net_pay,
                'tax_withheld' => $request->tax_withheld,
                'salary_method' => $request->salary_method,
                'date' => $request->date,
            ]);
        }

        return redirect()->route('payroll.index')
        ->with('success','Employee Payroll is successfully updated.');
    }

    public function show($id)
    {
        // $employee_payroll = Payroll::find($id);
        // return view('payroll.show',compact('employee_payroll'));
    }

    public function getPayrollDestroy($pay_id=null)
        {
            $pr_alias = 'pr-'.$pay_id;
            Voucher::where('ref_number', $pr_alias)->delete();
            
            $key = 'cd-'.$pay_id;
            Cashadvance::where('keys', $key)->delete();
            
            Payroll::where('pay_id', $pay_id)->delete();
            return back()->with('success', 'Employee Payroll is successfully deleted...');
        }

    public function payrollDetails(Request $request)
    {
       $employees_payrolls = DB::table('employees')
            ->join('payrolls', 'employees.id', '=', 'payrolls.e_id')
            ->select('employees.*', 'payrolls.*', 'employees.id as id')
            ->orderBy('employee_name', 'ASC')
            ->orderBy('payrolls.created_at', 'ASC')
            ->paginate(10);
            // dd($employees_payrolls);
           return view('payroll.payroll-details', compact('employees_payrolls'))
          ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    public function payrollDetailsByName(Request $request)
    {

        if(!empty($request->search_emp_name)){

            $employees_payrolls = DB::table('employees')
            ->join('payrolls', 'employees.id', '=', 'payrolls.e_id')
            ->select('employees.*', 'payrolls.*', 'employees.id as id')
            ->where('employee_name', 'LIKE', '%'.$request->search_emp_name.'%')
            ->orderBy('payrolls.created_at', 'ASC')
            ->paginate(10);

           return view('payroll.payroll-details', compact('employees_payrolls'))
          ->with('i', ($request->input('page', 1) - 1) * 5);
        
        }else{

            $start = $request->date_from;
            $end = $request->date_to;

            $employees_payrolls = DB::table('payrolls')
            ->join('employees', 'payrolls.e_id', '=', 'employees.id')
            ->select('employees.*', 'payrolls.*')
            ->whereBetween('payrolls.created_at', array($start, $end))
            ->orderBy('employee_name', 'ASC')
            ->orderBy('payrolls.created_at', 'ASC')
            ->paginate(10);

           return view('payroll.payroll-details', compact('employees_payrolls'))
          ->with('i', ($request->input('page', 1) - 1) * 5);
        }
           
    }

}
