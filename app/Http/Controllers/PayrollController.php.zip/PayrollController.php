<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use App\Payroll;
use DB;
use Carbon\Carbon;
use DateTime;

class PayrollController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $employees_payrolls = DB::table('employees')
            ->join('dummy_payrolls', 'employees.id', '=', 'dummy_payrolls.e_id')
            ->leftJoin('payrolls', 'employees.id', '=', 'payrolls.e_id')
            ->select('employees.*', 'dummy_payrolls.*', 'payrolls.*', 'employees.id as id', 'employees.salary_method','employees.absent_rate as absent_rate','employees.late_rate as late_rate','employees.overtime_rate as overtime_rate', 'dummy_payrolls.e_id as e_id', 'payrolls.created_at as created_at', 'payrolls.pay_id as pay_id')
            ->orderBy('employee_name', 'ASC')
            ->orderBy('payrolls.created_at', 'DESC')
            ->groupBy('employees.id')
            ->paginate(10);

           return view('payroll.index', compact('employees_payrolls'))
           ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    
    public function update(Request $request)
    {

        foreach ($request->payrow as $payroll) {

            if (!empty($payroll['e_id']) && $payroll['salary_method'] == "D") {

                DB::table('payrolls')->where('e_id', '=', $payroll['e_id'])
                ->insert(array(
                'e_id' => $payroll['e_id'],
                'salary_days_present' =>  $payroll['salary_days_present'],
                'salary_rate' => $payroll['salary_rate'],
                'salary_total' => $payroll['salary_total'],
                'overtime' => $payroll['overtime'],
                'overtime_rate' => $payroll['overtime_rate'],
                'overtime_total' => $payroll['overtime_total'],
                'cola' => $payroll['cola'],
                'total' => $payroll['total'],
                'emp_con_sss' => $payroll['emp_con_sss'],
                'emp_con_phic' => $payroll['emp_con_phic'],
                'emp_con_pagibig' => $payroll['emp_con_pagibig'],
                'late' => $payroll['late'],
                'late_rate' => $payroll['late_rate'],
                'late_total' => $payroll['late_total'],
                'employer_con_sss' => $payroll['employer_con_sss'],
                'employer_con_phic' => $payroll['employer_con_phic'],
                'employer_con_pagibig' => $payroll['employer_con_pagibig'],
                'holiday' => $payroll['holiday'],
                'net_pay' => $payroll['net_pay'],
                'tax_withheld' => $payroll['tax_withheld'],
                'salary_method' => $payroll['salary_method'],
                ));
            }elseif (!empty($payroll['e_id']) && $payroll['salary_method'] == "M"){

                DB::table('payrolls')->where('e_id', '=', $payroll['e_id'])
                ->insert(array(
                'e_id' => $payroll['e_id'],
                'salary_rate' => $payroll['salary_rate'],
                'salary_total' => $payroll['salary_total'],
                'overtime' => $payroll['overtime'],
                'overtime_rate' => $payroll['overtime_rate'],
                'overtime_total' => $payroll['overtime_total'],
                'cola' => $payroll['cola'],
                'total' => $payroll['total'],
                'emp_con_sss' => $payroll['emp_con_sss'],
                'emp_con_phic' => $payroll['emp_con_phic'],
                'emp_con_pagibig' => $payroll['emp_con_pagibig'],
                'late' => $payroll['late'],
                'late_rate' => $payroll['late_rate'],
                'late_total' => $payroll['late_total'],
                'employer_con_sss' => $payroll['employer_con_sss'],
                'employer_con_phic' => $payroll['employer_con_phic'],
                'employer_con_pagibig' => $payroll['employer_con_pagibig'],
                'days_absent' => $payroll['days_absent'],
                'absent_rate' => $payroll['absent_rate'],
                'absent_total' => $payroll['absent_total'],
                'holiday' => $payroll['holiday'],
                'net_pay' => $payroll['net_pay'],
                'tax_withheld' => $payroll['tax_withheld'],
                'salary_method' => $payroll['salary_method'],
                ));
            }
        }
            return redirect()->route('payroll.index')
                ->with('success','Employee Payroll is save.');
    }

    /*public function show($id)
    {
        $employee_payroll = Payroll::find($id);
        return view('payroll.show',compact('employee_payroll'));
    }*/

    public function getPayrollDestroy($pay_id=null)
        {
            Payroll::where('pay_id', '=', $pay_id)->delete();
                return redirect()->route('payroll.index')
                    ->with('success','Employee is successfully removed from the Payroll');
        }

    public function payrollDetails(Request $request)
    {
       $employees_payrolls = DB::table('employees')
            ->join('payrolls', 'employees.id', '=', 'payrolls.e_id')
            ->select('employees.*', 'payrolls.*', 'employees.id as id')
            ->orderBy('employee_name', 'ASC')
            ->paginate(10);

           return view('payroll.payroll-details', compact('employees_payrolls'))
          ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    public function payrollDetailsByName(Request $request)
    {

        if(!empty($request->search_emp_name)){

            $employees_payrolls = DB::table('employees')
            ->join('payrolls', 'employees.id', '=', 'payrolls.e_id')
            ->select('employees.*', 'payrolls.*', 'employees.id as id')
            ->where('employee_name', 'LIKE', '%'.$request->search_emp_name.'%')
            ->orderBy('payrolls.created_at', 'DESC')
            ->paginate(10);

           return view('payroll.payroll-details', compact('employees_payrolls'))
          ->with('i', ($request->input('page', 1) - 1) * 5);
        
        }else{

            $start = $request->date_from;
            $end = $request->date_to;

            $employees_payrolls = DB::table('payrolls')
            ->join('employees', 'payrolls.e_id', '=', 'employees.id')
            ->select('employees.*', 'payrolls.*')
            ->whereBetween('payrolls.created_at', array($start, $end))
            ->orderBy('employee_name', 'ASC')
            ->paginate(10);

           return view('payroll.payroll-details', compact('employees_payrolls'))
          ->with('i', ($request->input('page', 1) - 1) * 5);
        }
           
    }

}
