@extends('layouts.adminlte')

@section('body_classes')

@if(isset($view_name)){{$view_name}}@endif

@endsection

@section('content')

<div class="content-wrapper">
    <div class="row">
        <section class="content-header">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h1>Create Monthly Payroll</h1>
            </div>
        </div>
        <div style="clear: both;"></div>
        </section>
    </div>

    {{-- @if ($message = Session::get('success'))
        <div class="alert alert-success alert-employee">
            <p>{{ $message }}</p>
        </div>
    @endif --}}

    <section class="row payroll-section">
        {!! Form::open(array('url' => 'payroll/save-payroll','method'=>'GET')) !!}
            <div class="col-lg-12">
                <div class="row input-row">
                    <div class="col-md-6">
                        <label>Name:</label>
                        <input type="text" name="employee_name" value="{{$employees_data->employee_name}}" class="form-control" readonly>
                        <input type="hidden" name="e_id" value="{{$employees_data->id}}" class="form-control">
                        <input type="hidden" name="salary_method" value="{{$employees_data->salary_method}}" class="form-control">
                    </div>
                    <div class="col-md-3">
                        <label>TIN:</label>
                        <input type="text" name="tin_no" value="{{$employees_data->tin_no}}" class="form-control" readonly>
                    </div>
                    <div class="col-md-3">
                        <label>Status:</label>
                        <input type="text" name="status" value="{{$employees_data->status}}" class="form-control" readonly>
                    </div>
                </div>
                <div class="row divider">
                    <label>Salary</label>
                </div>
                <div class="row input-row">
                    <div class="col-md-2">
                        <label>Monthly Rate:</label>
                        <input type="text" name="salary_rate" value="{{$employees_data->monthly_rate}}" class="form-control salary_rate" readonly>
                    </div>
                    <div class="col-md-2">
                        <label>Salary Total:</label>
                        <input type="text" name="salary_total" value="" class="form-control salary_total" readonly>
                    </div>
                </div>
                <div class="row divider">
                    <label>Overtime</label>
                </div>
                <div class="row input-row">
                    <div class="col-md-2">
                        <label>Overtime:</label>
                        <input type="text" name="overtime" value="" class="form-control overtime">
                    </div>
                    <div class="col-md-2">
                        <label>Overtime Rate:</label>
                        <input type="text" name="overtime_rate" value="{{$employees_data->overtime_rate}}" class="form-control overtime_rate" readonly>
                    </div>
                    <div class="col-md-2">
                        <label>Overtime Total:</label>
                        <input type="text" name="overtime_total" value="" class="form-control overtime_total" readonly>
                    </div>
                </div>
                <div class="row divider">
                    <label>COLA</label>
                </div>
                <div class="row input-row">
                    <div class="col-md-2">
                        <label>Cola:</label>
                        <input type="text" name="cola" value="" class="form-control cola">
                    </div>
                    <div class="col-md-2">
                        <label>Total:</label>
                        <input type="text" name="total" value="" class="form-control total" readonly>
                    </div>
                </div>
                <div class="row divider">
                    <label>Employee's Contribution</label>
                </div>
                <div class="row input-row">
                    <div class="col-md-2">
                        <label>SSS:</label>
                        <input type="text" name="emp_con_sss" value="" class="form-control emp_con_sss">
                    </div>
                    <div class="col-md-2">
                        <label>PHIC:</label>
                        <input type="text" name="emp_con_phic" value="" class="form-control emp_con_phic">
                    </div>
                    <div class="col-md-2">
                        <label>PAG IBIG:</label>
                        <input type="text" name="emp_con_pagibig" value="" class="form-control emp_con_pagibig">
                    </div>
                </div>
                <div class="row divider">
                    <label>Late</label>
                </div>
                <div class="row input-row">
                    <div class="col-md-2">
                        <label>Late:</label>
                        <input type="text" name="late" value="" class="form-control late">
                    </div>
                    <div class="col-md-2">
                        <label>Late Rate:</label>
                        <input type="text" name="late_rate" value="{{$employees_data->late_rate}}" class="form-control late_rate" readonly>
                    </div>
                    <div class="col-md-2">
                        <label>Late Total:</label>
                        <input type="text" name="late_total" value="" class="form-control late_total" readonly>
                    </div>
                </div>
                <div class="row divider">
                    <label>Employer's Contribution</label>
                </div>
                <div class="row input-row">
                    <div class="col-md-2">
                        <label>SSS:</label>
                        <input type="text" name="employer_con_sss" value="" class="form-control">
                    </div>
                    <div class="col-md-2">
                        <label>PHIC:</label>
                        <input type="text" name="employer_con_phic" value="" class="form-control">
                    </div>
                    <div class="col-md-2">
                        <label>PAG IBIG:</label>
                        <input type="text" name="employer_con_pagibig" value="" class="form-control">
                    </div>
                </div>
                <div class="row divider">
                    <label>Absent</label>
                </div>
                <div class="row input-row">
                    <div class="col-md-2">
                        <label>No. of days absent:</label>
                        <input type="text" name="days_absent" value="" class="form-control days_absent">
                    </div>
                    <div class="col-md-2">
                        <label>Absent Rate:</label>
                        <input type="text" name="absent_rate" value="{{$employees_data->absent_rate}}" class="form-control absent_rate" readonly>
                    </div>
                    <div class="col-md-2">
                        <label>Absent Total:</label>
                        <input type="text" name="absent_total" value="" class="form-control absent_total" readonly>
                    </div>
                </div>
                <div class="row divider">
                    <label>Holiday, Net Pay and Tax Withheld</label>
                </div>
                <div class="row input-row">
                    <div class="col-md-2">
                        <label>Holiday:</label>
                        <input type="text" name="holiday" value="" class="form-control holiday">
                    </div>
                    <div class="col-md-2">
                        <label>Tax Withheld:</label>
                        <input type="text" name="tax_withheld" value="" class="form-control tax_withheld">
                    </div>
                    <div class="col-md-2">
                        <label>Net Pay:</label>
                        <input type="text" name="net_pay" value="" class="form-control net_pay" readonly>
                    </div>
                </div>
                <div class="row btn-border">
                    <button type="submit" class="btn btn-primary">Save Payroll</button>
                </div>
            </div>
        {!! Form::close() !!}
    </section>
</div>
@endsection

@section('footer_script')

<script type="text/javascript">

function commaSeparateNumber(val){
    while (/(\d+)(\d{3})/.test(val.toString())){
        val = val.toString().replace(/(\d+)(\d{3})/, '$1'+','+'$2');
    }
    return val;
}

$(document).ready(function(){

    var salary_rate = $("input.salary_rate").val() || 0;
    var salary_total = parseFloat(salary_rate);
    $("input.salary_total").val(commaSeparateNumber(salary_total.toFixed(2)));

    $("input").change(function(){

        var overtime = $("input.overtime").val() || 0;             
        var overtime_rate = $("input.overtime_rate").val() || 0;
        var overtime_total = parseFloat(overtime) * parseFloat(overtime_rate);
        $("input.overtime_total").val(commaSeparateNumber(overtime_total.toFixed(2)));

        var cola = $("input.cola").val() || 0;
        var total_cola = parseFloat(salary_total) + parseFloat(overtime_total) + parseFloat(cola);
        $("input.total").val(commaSeparateNumber(total_cola.toFixed(2)));

        var days_absent = $("input.days_absent").val() || 0;
        var absent_rate = $("input.absent_rate").val() || 0;
        var absent_total = parseFloat(days_absent) * parseFloat(absent_rate);
        $("input.absent_total").val(commaSeparateNumber(absent_total.toFixed(2)));

        var late = $("input.late").val() || 0;
        var late_rate = $("input.late_rate").val() || 0;
        var late_total = parseFloat(late) * parseFloat(late_rate);
        $("input.late_total").val(commaSeparateNumber(late_total.toFixed(2)));

        var emp_con_sss = $("input.emp_con_sss").val() || 0;
        var emp_con_phic = $("input.emp_con_phic").val() || 0;
        var emp_con_pagibig = $("input.emp_con_pagibig").val() || 0;
        var tax_withheld = $("input.tax_withheld").val() || 0;
        var holiday = $("input.holiday").val() || 0;
        var net_pay = (parseFloat(total_cola) + parseFloat(holiday)) - (parseFloat(emp_con_sss) + parseFloat(emp_con_phic) + parseFloat(emp_con_pagibig) + parseFloat(late_total) + parseFloat(tax_withheld) + parseFloat(absent_total));
        $("input.net_pay").val(commaSeparateNumber(net_pay.toFixed(2)));
    });  
});
</script>

<style type="text/css">
section.payroll-section{
    margin: 15px 15px 0;
    max-width: 1024px;
    padding-bottom: 15px;
}
section.payroll-section .col-lg-12{
    background-color: #fff;
    padding: 15px;
}
/* section.payroll-section .col-md-2{
    padding-right: 5px;
    padding-left: 5px;
} */
.input-row{
    padding: 5px 0;
}
.divider{
    background-color: #3c8dbc;
    text-align: left;
    color: #fff;
    padding: 5px 0 0 10px;
    margin: 10px 0 5px;
    text-transform: uppercase;
}
.btn-border{
    margin: 10px 0 0;
    border-top: 1px solid #3c8dbc;
    padding-top: 15px;
}
</style>

@endsection