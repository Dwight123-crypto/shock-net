<table class="account-row-template" style="display:none"><tbody>
@include('adjustment.account-row-template')
</tbody></table>
