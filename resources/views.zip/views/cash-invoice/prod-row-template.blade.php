<table class="prod-row-template" style="display:none"><tbody>

<tr class="prod-row">

  <td class="name">

    <input type="hidden" name="products[{num}][product_id]" class="product_id" />

    <input type="text" name="products[{num}][name]" class="name" readonly />

  </td>

  <td class="qty"><input type="text" name="products[{num}][qty]" class="qty" readonly /></td>

  <td class="price"><input type="text" name="products[{num}][price]" class="price" /></td>

  <td class="subtotal"><input type="text" name="products[{num}][amount]" class="subtotal" readonly /></td>

</tr>

</tbody></table>

