<table class="serv-row-template" style="display:none"><tbody>
<tr class="serv-row">
  <td class="name">
    <input type="hidden" name="services[{num}][service_id]" class="service_id" />
    <input type="text" name="services[{num}][name]" class="name" readonly />
  </td>
  <td class="subtotal"><input type="text" name="services[{num}][amount]" class="subtotal" readonly /></td>
</tr>
</tbody></table>
