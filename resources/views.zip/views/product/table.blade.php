<table class="prod-row-template" style="display:none"><tbody>
@include('product.table_row')
</tbody></table>
