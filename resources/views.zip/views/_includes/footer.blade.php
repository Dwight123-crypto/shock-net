<!-- Main Footer -->

<footer class="main-footer">

    <!-- To the right -->

    <div class="pull-right hidden-xs">

        Stress on expenses and taxes? Our system we’ll do your bookkeeping. 

    </div>

    <!-- Default to the left -->

    <strong>Copyright © 2018 <a href="#">Botkeeping</a>.</strong> All rights reserved.

</footer>

