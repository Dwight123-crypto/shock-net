<style>
h3.report-title { margin-bottom: 20px; }
th.balance { width: 140px; }
.table td.account-name { padding-left: 20px; }
.table tr.less-pad td { padding-top: 0; padding-bottom: 0; }
@if(Request::input('action') == 'pdf')
table thead th { background-color: #f5f5f5; }
.text-bold { font-weight: bold; }
.text-right { text-align: right; }
table.no-border tr th, table.no-border tr td { border-top: 1px solid #fff; }
@endif
</style>

@if(Request::input('action') == 'html')
<div class="text-right" style="padding-top: 20px;"><a href="{{ $pdf_link }}" class="btn btn-default btn-pdf"><i class="fa fa-file-pdf-o text-danger"></i> PDF</a></div>
@endif

<h3 class="report-title text-center">{{ $company }}<br>
Statement of Finance Position<br>
As of {{ $dates['date'] }}</h3>

<table class="table no-border table-hover">
    <thead style="border-bottom: 1px solid">
      <tr>
        <th> </th>
        <th class="amount text-right"> Current Year ({{ $dates['this_year'] }}) </th>
        <th class="amount text-right"> Last Year ({{ $dates['last_year'] }}) </th>
      </tr>
    </thead>
    <tbody>
    @foreach($sfp as $at_name => $at)
      <tr class="account-type text-bold"><td colspan="3">{{ $at_name }}</td></tr>
        @foreach($at as $sat_name => $sat)
          <tr class="sub-account-type"><td colspan="3">{{ $sat_name }}</td></tr>
          @foreach($sat as $r)
            <tr>
              <td class="account-name"> {{ $r->level1_coa }} </td>
              <td class="text-right"> {{ number_format($r->balance, 2, '.', ',') }} </td>
              <td class="text-right"> {{ number_format($r->prev_balance, 2, '.', ',') }} </td>
            </tr>
          @endforeach
          <tr class="total-row sub-account-type text-bold">
            <td> Total {{ ucwords( strtolower($sat_name) ) }} </td>
            <td class="text-right" style="border-top:1px solid #999"> {{ number_format($totals[$at_name][$sat_name]['balance'], 2, '.', ',') }} </td>
            <td class="text-right" style="border-top:1px solid #999"> {{ number_format($totals[$at_name][$sat_name]['prev_balance'], 2, '.', ',') }} </td>
          </tr>
        @endforeach
      <tr class="total-row account-type text-bold">
        <td> Total {{ ucwords( strtolower($at_name) ) }} </td>
        <td class="text-right" style="border-top:1px solid #999"> {{ number_format($totals[$at_name]['--total--']['balance'], 2, '.', ',') }} </td>
        <td class="text-right" style="border-top:1px solid #999"> {{ number_format($totals[$at_name]['--total--']['prev_balance'], 2, '.', ',') }} </td>
      </tr>
      <tr><td colspan="3"> &nbsp; </td></tr>
    @endforeach
      <?php
      $li_eq['balance']  = isset($totals[ $li_eq['li_label'] ]) ? $totals[ $li_eq['li_label'] ]['--total--']['balance'] : 0;
      $li_eq['balance'] += isset($totals[ $li_eq['eq_label'] ]) ? $totals[ $li_eq['eq_label'] ]['--total--']['balance'] : 0;
      
      $li_eq['prev_balance']  = isset($totals[ $li_eq['li_label'] ]) ? $totals[ $li_eq['li_label'] ]['--total--']['prev_balance'] : 0;
      $li_eq['prev_balance'] += isset($totals[ $li_eq['eq_label'] ]) ? $totals[ $li_eq['eq_label'] ]['--total--']['prev_balance'] : 0;
      ?>
      <tr class="total-row text-bold">
        <td style="border-top:1px solid"> TOTAL Liabilities and Equity </td>
        <td class="text-right" style="border-top:1px solid"> {{ number_format($li_eq['balance'], 2, '.', ',') }} </td>
        <td class="text-right" style="border-top:1px solid"> {{ number_format($li_eq['prev_balance'], 2, '.', ',') }} </td>
      </tr>
    </tbody>
</table>
