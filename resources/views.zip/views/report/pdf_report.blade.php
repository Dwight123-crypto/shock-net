@extends('layouts.pdf_tpl')


@section('content')
{!! $content !!}
@endsection
